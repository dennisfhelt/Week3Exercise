package edu.matc.entity;

/**
 * TODO At minimum, complete the following
 * TODO create no-arg constructor
 * TODO create getters and setters
 * TODO add hibernate annotations
 * TODO Javadoc comments
 */
public class Book {
    private String title;
    private String author;
    private int id;
    private String isbn;
    private int publicationYear;
}
