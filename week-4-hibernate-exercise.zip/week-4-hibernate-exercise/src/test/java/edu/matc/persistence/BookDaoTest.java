package edu.matc.persistence;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

// TODO add unit tests to achieve 100% code coverage of your dao.
// TODO You should run these tests repeatedly, in any order, and they should all pass every time!
// TODO Javadoc comments
class BookDaoTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void getById() {
    }

    @Test
    void saveOrUpdate() {
    }

    @Test
    void insert() {
    }

    @Test
    void delete() {
    }

    @Test
    void getAll() {
    }
}